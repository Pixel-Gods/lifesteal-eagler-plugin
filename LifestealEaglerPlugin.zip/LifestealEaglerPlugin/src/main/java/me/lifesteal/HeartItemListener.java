package me.lifesteal;

import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.*;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

public class HeartItemListener implements Listener {

    @EventHandler
    public void onUse(PlayerInteractEvent e) {
        if (e.getItem() == null) return;

        ItemStack item = e.getItem();
        if (item.getType() != Material.NETHER_STAR) return;

        ItemMeta meta = item.getItemMeta();
        if (meta == null || !meta.hasDisplayName()) return;
        if (!meta.getDisplayName().equals("§cHeart")) return;

        Player player = e.getPlayer();

        player.setMaxHealth(player.getMaxHealth() + 2.0);
        item.setAmount(item.getAmount() - 1);
        player.sendMessage("§aYou gained §c1 heart§a!");
        e.setCancelled(true);
    }
}

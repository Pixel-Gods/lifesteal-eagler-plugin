package me.lifesteal;

import org.bukkit.Material;
import org.bukkit.command.*;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

public class WithdrawCommand implements CommandExecutor {

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {

        if (!(sender instanceof Player)) {
            sender.sendMessage("Only players can use this command.");
            return true;
        }

        Player player = (Player) sender;
        double maxHealth = player.getMaxHealth();

        if (maxHealth <= 2.0) {
            player.sendMessage("§cYou only have 1 heart left!");
            return true;
        }

        player.setMaxHealth(maxHealth - 2.0);

        ItemStack heart = new ItemStack(Material.NETHER_STAR);
        ItemMeta meta = heart.getItemMeta();
        if (meta != null) {
            meta.setDisplayName("§cHeart");
            heart.setItemMeta(meta);
        }

        player.getInventory().addItem(heart);
        player.sendMessage("§aYou withdrew §c1 heart§a.");

        return true;
    }
}

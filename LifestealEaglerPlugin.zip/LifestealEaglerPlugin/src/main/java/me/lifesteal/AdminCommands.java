package me.lifesteal;

import org.bukkit.command.*;
import org.bukkit.entity.Player;

public class AdminCommands implements CommandExecutor {

    private final InviteManager inviteManager;

    public AdminCommands(InviteManager inviteManager) {
        this.inviteManager = inviteManager;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {

        if (args.length != 1) return true;

        Player target = sender.getServer().getPlayer(args[0]);
        if (target == null) return true;

        if (cmd.getName().equalsIgnoreCase("invite")) {
            inviteManager.invite(target.getUniqueId());
            sender.sendMessage("§aInvited " + target.getName());
        }

        if (cmd.getName().equalsIgnoreCase("uninvite")) {
            inviteManager.uninvite(target.getUniqueId());
            sender.sendMessage("§cUninvited " + target.getName());
        }

        return true;
    }
}

package me.lifesteal;

import org.bukkit.event.*;
import org.bukkit.event.player.PlayerJoinEvent;

public class JoinListener implements Listener {

    private final InviteManager inviteManager;

    public JoinListener(InviteManager inviteManager) {
        this.inviteManager = inviteManager;
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        if (!inviteManager.isInvited(e.getPlayer().getUniqueId())) {
            e.getPlayer().kickPlayer("§cGET OUT!");
        }
    }
}
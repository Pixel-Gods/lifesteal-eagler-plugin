package me.lifesteal;

import org.bukkit.plugin.java.JavaPlugin;

public class LifestealEaglerSMP extends JavaPlugin {

    private InviteManager inviteManager;

    @Override
    public void onEnable() {
        inviteManager = new InviteManager();

        getServer().getPluginManager().registerEvents(new HeartListener(), this);
        getServer().getPluginManager().registerEvents(new HeartItemListener(), this);
        getServer().getPluginManager().registerEvents(new JoinListener(inviteManager), this);

        AdminCommands admin = new AdminCommands(inviteManager);

        if (getCommand("invite") != null) getCommand("invite").setExecutor(admin);
        if (getCommand("uninvite") != null) getCommand("uninvite").setExecutor(admin);
        if (getCommand("withdraw") != null) getCommand("withdraw").setExecutor(new WithdrawCommand());
        if (getCommand("creative") != null) getCommand("creative").setExecutor(new CreativeCommand());

        getLogger().info("LifestealEaglerSMP enabled!");
    }

    @Override
    public void onDisable() {
        getLogger().info("LifestealEaglerSMP disabled!");
    }
}
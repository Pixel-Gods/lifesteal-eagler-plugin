package me.lifesteal;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

public class InviteManager {

    private final Set<UUID> invited = new HashSet<>();

    public void invite(UUID uuid) {
        invited.add(uuid);
    }

    public void uninvite(UUID uuid) {
        invited.remove(uuid);
    }

    public boolean isInvited(UUID uuid) {
        return invited.contains(uuid);
    }
}
package me.lifesteal;

import org.bukkit.entity.Player;
import org.bukkit.event.*;
import org.bukkit.event.entity.PlayerDeathEvent;

public class HeartListener implements Listener {

    @EventHandler
    public void onKill(PlayerDeathEvent e) {
        Player dead = e.getEntity();
        Player killer = dead.getKiller();

        if (killer == null) return;

        killer.setMaxHealth(killer.getMaxHealth() + 2.0);
        dead.setMaxHealth(Math.max(2.0, dead.getMaxHealth() - 2.0));
    }
}

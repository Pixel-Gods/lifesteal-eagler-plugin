package me.lifesteal;

import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

public class DeathBanManager {

    private final File file;
    private final FileConfiguration config;
    private final Set<UUID> banned = new HashSet<>();

    public DeathBanManager(File dataFolder) {
        file = new File(dataFolder, "deathbans.yml");

        if (!file.exists()) {
            try {
                file.createNewFile();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        config = YamlConfiguration.loadConfiguration(file);

        for (String uuid : config.getStringList("banned")) {
            banned.add(UUID.fromString(uuid));
        }
    }

    public void ban(UUID uuid) {
        banned.add(uuid);
        save();
    }

    public void unban(UUID uuid) {
        banned.remove(uuid);
        save();
    }

    public boolean isBanned(UUID uuid) {
        return banned.contains(uuid);
    }

    private void save() {
        config.set("banned", banned.stream().map(UUID::toString).toArray());
        try {
            config.save(file);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
